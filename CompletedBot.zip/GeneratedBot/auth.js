const BOT_TOKEN = '237u1293712'; 
const BOT_NAME = 'ModBot'; 
const CLIENT_ID = '324732099080'; 
exports.BOT_TOKEN = BOT_TOKEN;
exports.BOT_NAME = BOT_NAME;
exports.CLIENT_ID = CLIENT_ID;

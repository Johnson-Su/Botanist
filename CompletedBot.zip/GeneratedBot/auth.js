const BOT_TOKEN = 'a'; 
const BOT_NAME = 'a'; 
exports.BOT_TOKEN = BOT_TOKEN;
exports.BOT_NAME = BOT_NAME;

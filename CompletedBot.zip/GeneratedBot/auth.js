const BOT_TOKEN = 'botbot'; 
const BOT_NAME = '283746782364'; 
exports.BOT_TOKEN = BOT_TOKEN;
exports.BOT_NAME = BOT_NAME;
